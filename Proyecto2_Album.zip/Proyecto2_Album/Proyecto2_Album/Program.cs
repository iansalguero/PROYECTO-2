﻿using System;

namespace Proyecto2_Album
{
    class Program
    {
        static Album album;

        static void Main(string[] args)
        {
            album = new Album();
        }
    }
}
