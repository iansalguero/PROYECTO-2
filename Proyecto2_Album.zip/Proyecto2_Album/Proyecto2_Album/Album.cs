﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto2_Album
{
    class Album
    {
        static string[] codigosEspeciales = new string[] { "FWC" };

        static int inicioEspeciales = 0;
        static int finEspeciales = 30;

        static string[] codigosSelecciones = new string[] {
            "QAT","ECU","SEN","NED",
            "ENG","IRN","USA","WAL",
            "ARG","KSA","MEX","POL",
            "FRA","AUS","DEN","TUN",
            "ESP","CRC","GER","JPN",
            "BEL","CAN","MAR","CRO",
            "BRA","SRB","SUI","CMR",
            "POR","GHA","URU","KOR"
        };

        static int inicioSelecciones = 1;
        static int finSelecciones = 20;

        public Estampa[] estampas;
        public int totalEstampas;

        public Album()
        {
            this.totalEstampas = (finEspeciales - inicioEspeciales) * codigosEspeciales.Length + (finSelecciones - inicioSelecciones) * codigosSelecciones.Length;
            estampas = new Estampa[totalEstampas];
            // codigo para crear estampas
        }
    }
}
